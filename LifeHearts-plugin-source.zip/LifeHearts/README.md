# LifeHearts (Paper 26.3 / Java 25)

Morir quita **un corazón de vida máxima permanente**. Se recupera comiendo un **Corazón** crafteado.
Nunca se banea a nadie: como mucho se baja hasta **medio corazón**.

## Cómo funciona
- **Al morir** pierdes 1 corazón de vida máxima, para siempre (10 → 9 → 8 …). Lo mínimo es **medio corazón**:
  a partir de ahí, morir ya no quita nada. Si un tótem evita la muerte, no se pierde nada.
- **Comer un Corazón** da +1 corazón de vida máxima y te cura ese corazón. **No hay límite** de cuántos puedes comer
  (puedes pasar de 10 corazones); el único tope es el de Minecraft, 512 corazones.
- Se come como cualquier comida (mantener clic derecho), aunque tengas la barra de hambre llena.
- La vida máxima se guarda en los datos de cada jugador, así que se mantiene al salir, al reiniciar el servidor y al morir.

## Receta del Corazón (mesa de crafteo)

    Tótem de la inmortalidad   Poción de Curación    Tótem de la inmortalidad
    Poción de Curación         Manzana de Notch      Poción de Curación
    Tótem de la inmortalidad   Poción de Curación    Tótem de la inmortalidad

- Manzana de Notch = manzana de oro encantada.
- Pociones de Curación (salud instantánea) normales, para beber. También vale la de Curación II (`allow-strong-healing`).
  Las arrojadizas y persistentes no valen.
- El Corazón no sirve como ingrediente de ninguna otra receta.

## Comandos
| Comando | Quién | Qué hace |
|---|---|---|
| `/corazones` o `/corazones info` | todos | Ver tu vida máxima permanente |
| `/corazones info <jugador>` | admin | Ver la de otro jugador |
| `/corazones give <jugador> [cantidad]` | admin | Dar objetos Corazón |
| `/corazones set <jugador> <corazones>` | admin | Fijar la vida máxima (p. ej. `10` o `0.5`) |
| `/corazones add <jugador> <corazones>` | admin | Sumar o restar (p. ej. `1` o `-1`) |
| `/corazones reset <jugador>` | admin | Volver a 10 corazones |

Alias: `/hearts`, `/lifehearts`. Permisos: `lifehearts.info` (todos) y `lifehearts.admin` (operadores).

## Configuración (`config.yml`)
- `hearts-lost-per-death: 1.0`: corazones que se pierden al morir (0.5 = medio).
- `min-hearts: 0.5`: mínimo de vida máxima.
- `hearts-per-item: 1.0`: corazones que da cada Corazón.
- `allow-strong-healing: true`: si vale la Poción de Curación II en la receta.
- `show-real-hearts: true`: la barra de vida muestra siempre los corazones reales. Quita el escalado de corazones de otros plugins
  (p. ej. AuraSkills con `health-scaling`); si usas AuraSkills, pon también su `health-scaling` en `false` para evitar un parpadeo.
- `item-model: "lifehearts:heart"`: textura del Corazón (ver abajo). Con `""` se ve como una fruta de coro reventada con brillo.

## Textura (resource pack)
El Corazón usa la textura `lifehearts:heart` (el corazón de la barra de vida, a 32x32), incluida en el resource pack del servidor (el de InfernalArmor).
Copia de los archivos en `resourcepack-addon/` por si usas otro pack: cópialos dentro de tu pack.
Sin el pack actualizado el Corazón se ve como un cuadro morado y negro.

## Compilar
    mvn package     ->  target/LifeHearts.jar
(o el workflow de GitHub `.github/workflows/build.yml`). Copia el jar en `plugins/` y reinicia el servidor.

## Detalles técnicos
- La vida se cambia con un modificador del atributo de vida máxima (`lifehearts:extra_health`), no con el valor base,
  así otros efectos (Salud Mejorada, otros plugins) siguen sumando por encima.
- El Corazón es una fruta de coro reventada (objeto sin otros usos) con el componente "consumable" y una marca propia.
- Código: `HeartManager` (guardar/aplicar), `HeartMath` (cálculos), `HeartItem` (objeto y receta),
  `HeartListener` (muerte, reaparecer, comer, proteger recetas), `HeartCommand` (`/corazones`).
