package dev.lifehearts;

import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Guarda cuántos puntos de vida máxima ha ganado o perdido cada jugador (en sus datos, así sobrevive a reinicios)
 * y lo aplica como un modificador del atributo de vida máxima. No se toca el valor base, así otros plugins o efectos
 * (p. ej. Salud Mejorada) siguen sumando por encima.
 */
final class HeartManager {

    private final NamespacedKey modifierKey;
    private final NamespacedKey dataKey;
    private final double lossPoints;
    private final double minPoints;
    private final double gainPoints;
    private final boolean showRealHearts;

    HeartManager(JavaPlugin plugin) {
        this.modifierKey = new NamespacedKey(plugin, "extra_health");
        this.dataKey = new NamespacedKey(plugin, "extra_health");
        // config en corazones -> puntos de vida
        this.lossPoints = Math.max(0.0, plugin.getConfig().getDouble("hearts-lost-per-death", 1.0)) * 2.0;
        this.minPoints = Math.max(1.0, plugin.getConfig().getDouble("min-hearts", 0.5) * 2.0);
        this.gainPoints = Math.max(0.0, plugin.getConfig().getDouble("hearts-per-item", 1.0)) * 2.0;
        this.showRealHearts = plugin.getConfig().getBoolean("show-real-hearts", true);
    }

    double minPoints() {
        return minPoints;
    }

    /** Puntos ganados (+) o perdidos (-) respecto a la vida base. */
    double offset(Player player) {
        Double v = player.getPersistentDataContainer().get(dataKey, PersistentDataType.DOUBLE);
        return v == null ? 0.0 : v;
    }

    private AttributeInstance maxHealth(Player player) {
        return player.getAttribute(Attribute.MAX_HEALTH);
    }

    private double base(Player player) {
        AttributeInstance attr = maxHealth(player);
        return attr == null ? 20.0 : attr.getBaseValue();
    }

    /** Vida máxima permanente del jugador (base + lo ganado/perdido), sin contar efectos temporales. */
    double total(Player player) {
        return base(player) + offset(player);
    }

    /** Fija la vida máxima permanente (en puntos), la guarda y la aplica. */
    void setTotal(Player player, double totalPoints) {
        double clamped = Math.max(minPoints, Math.min(HeartMath.ATTRIBUTE_CAP, totalPoints));
        player.getPersistentDataContainer().set(dataKey, PersistentDataType.DOUBLE, clamped - base(player));
        apply(player);
    }

    /** Vuelve a poner el modificador según lo guardado (al entrar, al reaparecer y tras cada cambio). */
    void apply(Player player) {
        AttributeInstance attr = maxHealth(player);
        if (attr == null) return;
        AttributeModifier old = attr.getModifier(modifierKey);
        if (old != null) attr.removeModifier(old);
        double offset = offset(player);
        if (offset != 0.0) {
            attr.addModifier(new AttributeModifier(modifierKey, offset, AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.ANY));
        }
        double max = attr.getValue();
        if (player.getHealth() > max) player.setHealth(max);
        showRealHearts(player);
    }

    /**
     * show-real-hearts: quita el escalado de corazones que ponen otros plugins (p. ej. AuraSkills con health-scaling),
     * para que la barra de vida muestre la vida máxima real del jugador (9 corazones si tiene 9).
     */
    void showRealHearts(Player player) {
        if (showRealHearts && player.isHealthScaled()) player.setHealthScaled(false);
    }

    boolean showRealHeartsEnabled() {
        return showRealHearts;
    }

    /** Al morir. Devuelve los puntos perdidos (0 si ya estaba en el mínimo). */
    double loseOnDeath(Player player) {
        double before = total(player);
        double after = HeartMath.afterDeath(before, lossPoints, minPoints);
        if (after != before) setTotal(player, after);
        return before - after;
    }

    /** Al comer un Corazón. Devuelve los puntos ganados (0 si ya estaba en el tope de Minecraft). */
    double gainFromItem(Player player) {
        double before = total(player);
        double after = HeartMath.afterEating(before, gainPoints);
        if (after != before) setTotal(player, after);
        return after - before;
    }
}
