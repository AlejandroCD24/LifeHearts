package dev.lifehearts;

import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * LifeHearts: morir quita un corazón de vida máxima permanente (como mucho hasta medio corazón, nunca se banea),
 * y comer un "Corazón" crafteado devuelve uno, sin límite.
 */
public final class LifeHeartsPlugin extends JavaPlugin {

    private HeartItem heartItem;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        HeartManager hearts = new HeartManager(this);
        heartItem = new HeartItem(this);
        heartItem.registerRecipe();

        getServer().getPluginManager().registerEvents(new HeartListener(this, hearts, heartItem), this);

        PluginCommand command = getCommand("corazones");
        if (command != null) {
            HeartCommand executor = new HeartCommand(hearts, heartItem);
            command.setExecutor(executor);
            command.setTabCompleter(executor);
        }

        // Otros plugins (p. ej. AuraSkills) vuelven a poner su escalado de corazones al actualizar la vida:
        // se quita cada medio segundo para que la barra muestre siempre los corazones reales.
        if (hearts.showRealHeartsEnabled()) {
            getServer().getScheduler().runTaskTimer(this, () -> {
                for (Player player : getServer().getOnlinePlayers()) hearts.showRealHearts(player);
            }, 20L, 10L);
        }

        // por si el plugin se activa con jugadores conectados
        for (Player player : getServer().getOnlinePlayers()) hearts.apply(player);
        getLogger().info("Morir quita " + getConfig().getDouble("hearts-lost-per-death", 1.0) + " corazón(es); mínimo: "
                + getConfig().getDouble("min-hearts", 0.5) + "; cada Corazón da " + getConfig().getDouble("hearts-per-item", 1.0) + ".");
    }

    @Override
    public void onDisable() {
        if (heartItem != null) heartItem.unregisterRecipe();
    }
}
