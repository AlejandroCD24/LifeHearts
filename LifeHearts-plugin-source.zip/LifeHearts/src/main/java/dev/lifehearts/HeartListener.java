package dev.lifehearts;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Keyed;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

final class HeartListener implements Listener {

    private final JavaPlugin plugin;
    private final HeartManager hearts;
    private final HeartItem heartItem;

    HeartListener(JavaPlugin plugin, HeartManager hearts, HeartItem heartItem) {
        this.plugin = plugin;
        this.hearts = hearts;
        this.heartItem = heartItem;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        hearts.apply(event.getPlayer());
    }

    /** Morir quita corazones (nunca por debajo del mínimo). Un tótem evita la muerte, así que tampoco se pierde nada. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        double lost = hearts.loseOnDeath(player);
        if (lost > 0) {
            player.sendMessage(Component.text("Has perdido " + HeartMath.label(lost)
                    + " de forma permanente. Ahora tienes " + HeartMath.label(hearts.total(player)) + " de vida máxima.", NamedTextColor.RED));
        } else {
            player.sendMessage(Component.text("Estás en el mínimo (" + HeartMath.label(hearts.total(player))
                    + "): no pierdes más corazones.", NamedTextColor.GOLD));
        }
    }

    /** Al reaparecer, se vuelve a aplicar la vida máxima y se llena la vida. */
    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            hearts.apply(player);
            AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
            if (attr != null && !player.isDead()) player.setHealth(attr.getValue());
        });
    }

    /** Comer un Corazón: +1 corazón permanente, sin límite (salvo el tope de Minecraft). */
    @EventHandler(ignoreCancelled = true)
    public void onEat(PlayerItemConsumeEvent event) {
        if (!heartItem.isHeart(event.getItem())) return;
        Player player = event.getPlayer();
        double gained = hearts.gainFromItem(player);
        if (gained > 0) {
            AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
            double max = attr == null ? hearts.total(player) : attr.getValue();
            player.setHealth(Math.min(player.getHealth() + gained, max));
            player.sendMessage(Component.text("Has recuperado " + HeartMath.label(gained)
                    + ". Ahora tienes " + HeartMath.label(hearts.total(player)) + " de vida máxima.", NamedTextColor.GREEN));
        } else {
            event.setCancelled(true); // no se gasta el Corazón
            player.sendMessage(Component.text("Ya tienes el máximo de vida que permite Minecraft (512 corazones).", NamedTextColor.GOLD));
        }
    }

    /** El Corazón no sirve como ingrediente de ninguna otra receta (p. ej. el bloque de purpur). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        if (event.getRecipe() instanceof Keyed keyed && keyed.getKey().equals(heartItem.recipeKey())) return;
        for (ItemStack stack : event.getInventory().getMatrix()) {
            if (heartItem.isHeart(stack)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }
}
