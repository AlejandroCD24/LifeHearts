package dev.lifehearts;

import io.papermc.paper.datacomponent.DataComponentTypes;
import io.papermc.paper.datacomponent.item.Consumable;
import io.papermc.paper.datacomponent.item.ItemLore;
import io.papermc.paper.datacomponent.item.consumable.ItemUseAnimation;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.List;

/**
 * El objeto Corazón y su receta.
 *
 * <p>Se usa como base una fruta de coro reventada porque no tiene usos propios (no se come, no se coloca, no se da a ningún
 * animal); solo sirve en la receta de bloque de purpur, y eso se impide en {@link HeartListener}. Se hace comestible con el
 * componente "consumable" (se come aunque tengas la barra de hambre llena) y se reconoce por una marca en sus datos.
 */
final class HeartItem {

    private final JavaPlugin plugin;
    private final NamespacedKey markKey;
    private final NamespacedKey recipeKey;
    private final String model;

    HeartItem(JavaPlugin plugin) {
        this.plugin = plugin;
        this.markKey = new NamespacedKey(plugin, "heart");
        this.recipeKey = new NamespacedKey(plugin, "heart");
        this.model = plugin.getConfig().getString("item-model", "lifehearts:heart");
    }

    NamespacedKey recipeKey() {
        return recipeKey;
    }

    ItemStack create(int amount) {
        ItemStack item = new ItemStack(Material.POPPED_CHORUS_FRUIT, Math.max(1, amount));
        item.editMeta(meta -> meta.getPersistentDataContainer().set(markKey, PersistentDataType.BYTE, (byte) 1));
        item.setData(DataComponentTypes.ITEM_NAME, Component.text("Corazón", NamedTextColor.RED));
        item.setData(DataComponentTypes.LORE, ItemLore.lore()
                .addLine(gray("Cómelo para recuperar un corazón"))
                .addLine(gray("de vida máxima permanente."))
                .build());
        item.setData(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        item.setData(DataComponentTypes.CONSUMABLE, Consumable.consumable()
                .consumeSeconds(1.6f)
                .animation(ItemUseAnimation.EAT)
                .hasConsumeParticles(true)
                .build());
        if (model != null && !model.isBlank()) {
            item.setData(DataComponentTypes.ITEM_MODEL, Key.key(model));
        }
        return item;
    }

    boolean isHeart(ItemStack item) {
        if (item == null || item.getType() != Material.POPPED_CHORUS_FRUIT || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(markKey, PersistentDataType.BYTE);
    }

    /**
     * Mesa de crafteo:
     * <pre>
     *   Tótem   Poción  Tótem
     *   Poción  Notch   Poción
     *   Tótem   Poción  Tótem
     * </pre>
     * Pociones normales (para beber) de Curación, y de Curación II si allow-strong-healing es true.
     */
    void registerRecipe() {
        List<ItemStack> potions = new ArrayList<>();
        potions.add(potion(PotionType.HEALING));
        if (plugin.getConfig().getBoolean("allow-strong-healing", true)) potions.add(potion(PotionType.STRONG_HEALING));

        ShapedRecipe recipe = new ShapedRecipe(recipeKey, create(1));
        recipe.shape("TPT", "PAP", "TPT");
        recipe.setIngredient('T', new RecipeChoice.MaterialChoice(Material.TOTEM_OF_UNDYING));
        recipe.setIngredient('A', new RecipeChoice.MaterialChoice(Material.ENCHANTED_GOLDEN_APPLE));
        recipe.setIngredient('P', new RecipeChoice.ExactChoice(potions));
        Bukkit.addRecipe(recipe);
    }

    void unregisterRecipe() {
        Bukkit.removeRecipe(recipeKey);
    }

    private static ItemStack potion(PotionType type) {
        ItemStack potion = new ItemStack(Material.POTION);
        potion.editMeta(PotionMeta.class, meta -> meta.setBasePotionType(type));
        return potion;
    }

    private static Component gray(String text) {
        return Component.text(text, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false);
    }
}
