package dev.lifehearts;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * /corazones info [jugador]            ver la vida máxima permanente (la propia: todos; la de otros: admin)
 * /corazones give <jugador> [cantidad] dar objetos Corazón (admin)
 * /corazones set <jugador> <corazones> fijar la vida máxima permanente (admin)
 * /corazones add <jugador> <corazones> sumar o restar corazones, p. ej. -1 (admin)
 * /corazones reset <jugador>           volver a la vida normal (admin)
 */
final class HeartCommand implements CommandExecutor, TabCompleter {

    private static final String ADMIN = "lifehearts.admin";
    private static final String INFO = "lifehearts.info";

    private final HeartManager hearts;
    private final HeartItem heartItem;

    HeartCommand(HeartManager hearts, HeartItem heartItem) {
        this.hearts = hearts;
        this.heartItem = heartItem;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "info" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "info" -> {
                Player target;
                if (args.length >= 2) {
                    if (!sender.hasPermission(ADMIN)) return deny(sender);
                    target = player(sender, args[1]);
                } else if (sender instanceof Player p) {
                    if (!sender.hasPermission(INFO)) return deny(sender);
                    target = p;
                } else {
                    return usage(sender, label);
                }
                if (target == null) return true;
                sender.sendMessage(Component.text(target.getName() + " tiene " + HeartMath.label(hearts.total(target))
                        + " de vida máxima permanente.", NamedTextColor.YELLOW));
                return true;
            }
            case "give" -> {
                if (!sender.hasPermission(ADMIN)) return deny(sender);
                if (args.length < 2) return usage(sender, label);
                Player target = player(sender, args[1]);
                if (target == null) return true;
                int amount = 1;
                if (args.length >= 3) {
                    try {
                        amount = Math.max(1, Math.min(64, Integer.parseInt(args[2])));
                    } catch (NumberFormatException ex) {
                        return error(sender, "La cantidad tiene que ser un número entero.");
                    }
                }
                ItemStack item = heartItem.create(amount);
                target.getInventory().addItem(item).values()
                        .forEach(rest -> target.getWorld().dropItemNaturally(target.getLocation(), rest));
                sender.sendMessage(Component.text("Has dado " + amount + " Corazón(es) a " + target.getName() + ".", NamedTextColor.GREEN));
                return true;
            }
            case "set", "add" -> {
                if (!sender.hasPermission(ADMIN)) return deny(sender);
                if (args.length < 3) return usage(sender, label);
                Player target = player(sender, args[1]);
                if (target == null) return true;
                double value;
                try {
                    value = Double.parseDouble(args[2].replace(',', '.'));
                } catch (NumberFormatException ex) {
                    return error(sender, "Escribe un número de corazones, p. ej. 10 o 0.5.");
                }
                double points = sub.equals("set") ? value * 2.0 : hearts.total(target) + value * 2.0;
                hearts.setTotal(target, points);
                sender.sendMessage(Component.text(target.getName() + " tiene ahora " + HeartMath.label(hearts.total(target))
                        + " de vida máxima permanente.", NamedTextColor.GREEN));
                return true;
            }
            case "reset" -> {
                if (!sender.hasPermission(ADMIN)) return deny(sender);
                if (args.length < 2) return usage(sender, label);
                Player target = player(sender, args[1]);
                if (target == null) return true;
                hearts.setTotal(target, 20.0);
                sender.sendMessage(Component.text(target.getName() + " vuelve a tener " + HeartMath.label(hearts.total(target))
                        + ".", NamedTextColor.GREEN));
                return true;
            }
            default -> {
                return usage(sender, label);
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission(ADMIN);
        if (args.length == 1) {
            List<String> subs = admin ? List.of("info", "give", "set", "add", "reset") : List.of("info");
            for (String s : subs) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && admin) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        }
        return out;
    }

    private static Player player(CommandSender sender, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) sender.sendMessage(Component.text("El jugador " + name + " no está conectado.", NamedTextColor.RED));
        return p;
    }

    private static boolean deny(CommandSender sender) {
        return error(sender, "No tienes permiso para hacer eso.");
    }

    private static boolean error(CommandSender sender, String msg) {
        sender.sendMessage(Component.text(msg, NamedTextColor.RED));
        return true;
    }

    private static boolean usage(CommandSender sender, String label) {
        sender.sendMessage(Component.text("Uso: /" + label + " info [jugador] | give <jugador> [cantidad] | set <jugador> <corazones>"
                + " | add <jugador> <corazones> | reset <jugador>", NamedTextColor.YELLOW));
        return true;
    }
}
