package dev.lifehearts;

import java.util.Locale;

/**
 * Cálculos de vida máxima, en puntos de vida (1 corazón = 2 puntos). Es lógica pura para poder probarla sin servidor.
 */
final class HeartMath {

    /** Tope de Minecraft para la vida máxima (atributo max_health): 1024 puntos = 512 corazones. */
    static final double ATTRIBUTE_CAP = 1024.0;

    private HeartMath() {}

    /** Vida máxima tras morir: baja {@code loss} puntos, pero nunca por debajo de {@code min}. */
    static double afterDeath(double total, double loss, double min) {
        if (total <= min) return total;           // ya está en el mínimo (o por debajo por otro motivo): no se toca
        return Math.max(min, total - loss);
    }

    /** Vida máxima tras comer un Corazón: sube {@code gain} puntos, con el tope de Minecraft como único límite. */
    static double afterEating(double total, double gain) {
        return Math.min(ATTRIBUTE_CAP, total + gain);
    }

    /** Puntos de vida -> corazones como texto: 20 -> "10", 19 -> "9.5", 1 -> "0.5". */
    static String hearts(double points) {
        double h = Math.round(points) / 2.0;
        return h == Math.floor(h) ? String.valueOf((long) h) : String.format(Locale.ROOT, "%.1f", h);
    }

    /** Puntos de vida -> texto en español: 1 -> "medio corazón", 2 -> "1 corazón", 19 -> "9.5 corazones". */
    static String label(double points) {
        long p = Math.round(points);
        if (p == 1) return "medio corazón";
        if (p == 2) return "1 corazón";
        return hearts(points) + " corazones";
    }
}
